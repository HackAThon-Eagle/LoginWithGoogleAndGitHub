// SignUp.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider, GithubAuthProvider } from 'firebase/auth';
import { auth } from '../firebase';

const SignUp = () => {
  const navigate = useNavigate();

  const handleGoogleSignUp = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      navigate('/success');
    } catch (error) {
      console.error('Error signing up with Google:', error);
      alert('Failed to sign up with Google. Please try again.');
    }
  };

  const handleGithubSignUp = async () => {
    const provider = new GithubAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      navigate('/success');
    } catch (error) {
      console.error('Error signing up with GitHub:', error);
      alert('Failed to sign up with GitHub. Please try again.');
    }
  };

  return (
    <div className="w-full max-w-lg p-10 space-y-8 bg-white rounded shadow-md">
      <h2 className="text-3xl font-bold text-center text-gray-700">Sign Up</h2>
      <div className="mb-6 space-y-4">
        <button
          onClick={handleGoogleSignUp}
          className="w-full px-4 py-2 font-bold text-white bg-blue-500 rounded-full hover:bg-blue-700 focus:outline-none focus:shadow-outline"
        >
          Sign Up with Google
        </button>
        <button
          onClick={handleGithubSignUp}
          className="w-full px-4 py-2 font-bold text-white bg-gray-800 rounded-full hover:bg-gray-900 focus:outline-none focus:shadow-outline"
        >
          Sign Up with GitHub
        </button>
      </div>
    </div>
  );
};

export default SignUp;