// Form.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider, GithubAuthProvider } from 'firebase/auth';
import { auth } from '../firebase';

const Form = () => {
  const navigate = useNavigate();

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("Google Sign-In Successful", result.user);
      navigate('/success');
    } catch (error) {
      console.error('Error signing in with Google:', error);
      alert('Failed to sign in with Google. Please try again.');
    }
  };

  const handleGithubSignIn = async () => {
    const provider = new GithubAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("GitHub Sign-In Successful", result.user);
      navigate('/success');
    } catch (error) {
      console.error('Error signing in with GitHub:', error);
      alert('Failed to sign in with GitHub. Please try again.');
    }
  };

  return (
    <div className="w-full max-w-lg p-10 space-y-8 bg-white rounded shadow-md">
      <h1 className='bg-gradient-to-tr from-violet-500 to-pink-500 text-center text-5xl font-semibold text-white-700'>Welcome To LearnEasy</h1>
      <h2 className="text-3xl font-bold text-center text-gray-700">Sign In</h2>
      <div className="mb-6 space-y-4">
        <button
          onClick={handleGoogleSignIn}
          className="w-full px-4 py-2 font-bold text-white bg-blue-500 rounded-full hover:bg-blue-700 focus:outline-none focus:shadow-outline"
        >
          Sign In with Google
        </button>
        <button
          onClick={handleGithubSignIn}
          className="w-full px-4 py-2 font-bold text-white bg-gray-800 rounded-full hover:bg-gray-900 focus:outline-none focus:shadow-outline"
        >
          Sign In with GitHub
        </button>
      </div>
    </div>
  );
};

export default Form;