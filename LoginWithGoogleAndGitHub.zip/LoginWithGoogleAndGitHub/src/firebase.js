// firebase.js
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, GithubAuthProvider } from 'firebase/auth';

const firebaseConfig = {
    apiKey: "AIzaSyDajkwcHgcdxbucmE0xqQQpmME3TQjMTeI",
    authDomain: "innovationhackathonauth-cab57.firebaseapp.com",
    projectId: "innovationhackathonauth-cab57",
    storageBucket: "innovationhackathonauth-cab57.appspot.com",
    messagingSenderId: "370533839331",
    appId: "1:370533839331:web:bf3d12373228af144830d6"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider, GithubAuthProvider };