//App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Form from './components/Form';
import SignUp from './components/SignUp';
import SuccessPage from './components/SuccessPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <div className="flex w-full h-screen">
            <div className="w-full flex items-center justify-center lg:w-1/2">
              <Form />
            </div>
            <div className="hidden relative lg:flex h-full w-1/2 items-center justify-center bg-gray-200">
              <div className="w-60 h-60 bg-gradient-to-tr from-violet-500 to-pink-500 rounded-full animate-bounce"></div>
              <div className='w-full h-1/2 absolute bottom-0 bg-white/10 backdrop-blur-lg'/>
            </div>
          </div>
        } />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/success" element={<SuccessPage />} />
      </Routes>
    </Router>
  );
}

export default App;